from django.apps import AppConfig


class Belt1AppConfig(AppConfig):
    name = 'belt_1_app'
